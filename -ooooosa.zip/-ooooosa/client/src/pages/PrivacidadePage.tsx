import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Shield } from "lucide-react";
import { motion } from "framer-motion";

export default function PrivacidadePage() {
  const [, setLocation] = useLocation();

  const sections = [
    {
      title: "1. Informações que Coletamos",
      content: "Coletamos informações que você nos fornece diretamente ao criar uma conta, usar nossos serviços ou entrar em contato conosco. Isso inclui nome, email, dados de pagamento e informações financeiras da empresa."
    },
    {
      title: "2. Como Usamos suas Informações",
      content: "Utilizamos suas informações para fornecer, manter e melhorar nossos serviços, processar transações, enviar comunicações importantes e personalizar sua experiência."
    },
    {
      title: "3. Compartilhamento de Informações",
      content: "Não vendemos suas informações pessoais. Compartilhamos dados apenas com prestadores de serviços essenciais, quando exigido por lei ou com seu consentimento explícito."
    },
    {
      title: "4. Segurança dos Dados",
      content: "Implementamos medidas técnicas e organizacionais de segurança para proteger seus dados, incluindo criptografia, controles de acesso e monitoramento contínuo."
    },
    {
      title: "5. Seus Direitos",
      content: "Você tem direito a acessar, corrigir, excluir ou exportar seus dados pessoais a qualquer momento. Entre em contato conosco para exercer esses direitos."
    },
    {
      title: "6. Retenção de Dados",
      content: "Mantemos seus dados apenas pelo tempo necessário para cumprir as finalidades descritas nesta política ou conforme exigido por lei."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-gradient-to-r from-blue-600 to-cyan-600 flex items-center justify-center">
              <Shield className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            Política de Privacidade
          </h1>
          <p className="text-muted-foreground">
            Última atualização: 4 de novembro de 2024
          </p>
        </motion.div>

        <Card className="mb-8">
          <CardContent className="p-8">
            <p className="text-muted-foreground mb-6">
              No LUCREI, levamos sua privacidade a sério. Esta política descreve como coletamos, 
              usamos e protegemos suas informações pessoais.
            </p>

            <div className="space-y-6">
              {sections.map((section, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <h2 className="text-xl font-bold mb-2">{section.title}</h2>
                  <p className="text-muted-foreground">{section.content}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border-blue-500/20">
          <CardContent className="p-6 text-center">
            <h3 className="font-semibold mb-2">Dúvidas sobre privacidade?</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Entre em contato com nosso DPO (Data Protection Officer)
            </p>
            <Button 
              variant="outline"
              onClick={() => setLocation("/contato")}
            >
              Falar com DPO
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
